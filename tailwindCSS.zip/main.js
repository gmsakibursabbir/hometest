const navDialog = document.querySelector("#nav-dialog")
function handleMenu() {
   navDialog.classList.toggle("hidden");
}